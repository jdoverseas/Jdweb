# PentestMate (Web Version)

A simple OWASP Top 10 guide + manual pentest tips + PDF report generator.

## How to deploy
1. Upload to GitHub repo
2. Enable GitHub Pages from main branch
3. Done!

Developed by Ethical Hacker GPT.
