const owaspData = [
  {
    title: "1. Injection",
    description: "Example: SQL Injection, Command Injection. Testing: Use special characters. Fix: Prepared statements."
  },
  {
    title: "2. Broken Authentication",
    description: "Weak login, session hijack. Fix: Use MFA, secure cookies."
  },
  {
    title: "3. Sensitive Data Exposure",
    description: "HTTP instead of HTTPS, weak encryption. Fix: Use TLS."
  },
  {
    title: "4. XML External Entities (XXE)",
    description: "Test XML parsers. Fix: Disable external entity resolution."
  },
  {
    title: "5. Broken Access Control",
    description: "Test URL tampering. Fix: Server-side checks."
  },
  {
    title: "6. Security Misconfiguration",
    description: "Default creds, open ports. Fix: Harden servers."
  },
  {
    title: "7. Cross-Site Scripting (XSS)",
    description: "Test with <script>. Fix: Output encoding."
  },
  {
    title: "8. Insecure Deserialization",
    description: "Test deserialization. Fix: Use safe libs."
  },
  {
    title: "9. Using Components with Known Vulns",
    description: "Check outdated libs. Fix: Update."
  },
  {
    title: "10. Insufficient Logging & Monitoring",
    description: "Check audit logs. Fix: Log events securely."
  }
];

const listContainer = document.getElementById("owasp-list");
owaspData.forEach((item) => {
  const col = document.createElement("div");
  col.className = "col-md-4";
  col.innerHTML = `<div class="card h-100">
    <div class="card-body">
      <h5 class="card-title">${item.title}</h5>
      <p class="card-text">${item.description}</p>
    </div></div>`;
  listContainer.appendChild(col);
});

document.getElementById("report-form").addEventListener("submit", function (e) {
  e.preventDefault();
  const vuln = document.getElementById("vuln").value;
  const severity = document.getElementById("severity").value;
  const fix = document.getElementById("fix").value;

  const reportContent = `
    Pentest Report
    ==================
    Vulnerability: ${vuln}
    Severity: ${severity}
    Fix Suggestion: ${fix}
  `;

  const opt = {
    margin: 1,
    filename: `${vuln.replace(/\s+/g, '_')}_Report.pdf`,
    html2canvas: { scale: 2 },
    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
  };

  html2pdf().from(`<pre>${reportContent}</pre>`).set(opt).save();
});
